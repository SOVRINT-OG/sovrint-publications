SOVRINT™ MASTER RESONANCE ARCHITECTURE™
Katrina Pietroniro | v1.0 | 2026-10-02
Research archive; source limitations recorded; not a claim of complete corpus coverage

Read pdf/01_Master_White_Paper.pdf first, then pdf/04_Notation_and_Symbol_Registry.pdf. All files are indexed in release_manifest.json and SHA256SUMS.txt. Numerical data and parameters accompany all generated figures. Source originals and fetched records are retained with provenance. RIGHTS_AND_LICENSE.txt records the corpus-wide author-owned rights policy. No open-source license is granted. This archive has not been deposited in Zenodo and has no assigned DOI. Two failed uploads and source placeholders are disclosed in pdf/10_Provenance_and_Deposit_Guide.pdf.
