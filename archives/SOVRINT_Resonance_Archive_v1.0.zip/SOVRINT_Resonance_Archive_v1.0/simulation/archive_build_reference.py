from pathlib import Path
import json,re,csv,hashlib,shutil,zipfile,html,sys,platform
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from reportlab.platypus import SimpleDocTemplate,Paragraph,Spacer,Table,TableStyle,Image,Preformatted,KeepTogether
from reportlab.lib.styles import getSampleStyleSheet,ParagraphStyle
from reportlab.lib import colors
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.enums import TA_LEFT
from pypdf import PdfReader

ROOT=Path('output/SOVRINT_Resonance_Archive_v1.0')
for d in ['pdf','figures','tables','sources/uploaded','sources/connected','metadata','simulation','text']:(ROOT/d).mkdir(parents=True,exist_ok=True)
DATE='2026-10-02'; AUTHOR='Katrina Pietroniro'; VERSION='1.0'; STATUS='Research archive; source limitations recorded; not a claim of complete corpus coverage'
sources=json.loads(Path('tmp/corpus/all_sources.json').read_text())
source_rows=[]
for f in sorted(Path('project_sources').iterdir()):
 shutil.copy2(f,ROOT/'sources/uploaded'/f.name)
 source_rows.append([f'SRC-U{len(source_rows)+1:03}',f.name,'uploaded','Available original',hashlib.sha256(f.read_bytes()).hexdigest(),str((ROOT/'sources/uploaded'/f.name).relative_to(ROOT))])
for i,s in enumerate(sources):
 name=s.get('display_title',s.get('title','source'))
 name=re.sub(r'[^A-Za-z0-9_.-]','_',name)
 content=s.get('content') if s['kind']=='github' else s.get('text','')
 p=ROOT/'sources/connected'/f'{i+1:02}_{name}.txt';p.write_text(content,encoding='utf-8')
 source_rows.append([f'SRC-C{i+1:03}',s.get('display_title',s.get('title')) ,s['kind'],s.get('display_url',s.get('url')),hashlib.sha256(p.read_bytes()).hexdigest(),str(p.relative_to(ROOT))])
(ROOT/'sources/connected/connector_provenance.json').write_text(json.dumps(sources,ensure_ascii=False,indent=2))

RIGHTS='''SOVRINT™ CORPUS-WIDE RIGHTS NOTICE
© 2026 Katrina Pietroniro. All rights reserved. Existing original dates and notices remain preserved.
Scope: this notice records the author's rights policy for all SOVRINT™ works and original materials owned by Katrina Pietroniro, including architecture documents, books, papers, specifications, diagrams, tables, visual systems, glyphs, authored code, models, simulations, registries and original compilations, whether released separately or within this archive. The rights policy is corpus-wide; the files actually included in this archive are the bounded contents listed in the manifest.
Reference and research access: access is offered for reading, scholarly reference, citation and research evaluation. No general reproduction, reuse, redistribution, modification, adaptation, translation, derivative-work, training, implementation, sublicensing or commercial license is granted for protected content. Additional permissions require the rights holder's express written authorization.
Necessary platform hosting and preservation: the author authorizes the specifically requested repositories and platforms to receive, host and preserve this exact archive under their applicable service terms. This does not grant downstream users an open-source or permissive reuse license.
Statutory rights: this notice does not exclude uses independently permitted by applicable law, including fair dealing where applicable. Copyright protection attaches to protected expression; this notice does not assert ownership of general mathematical facts, ideas or established scientific equations merely because they are referenced here.
Third-party material: this notice applies only to rights owned or controlled by the author. Third-party terms, prior licenses and attribution remain applicable and cannot be revoked by this notice. No prior license is silently replaced. Recovered source materials retain their original notices and histories.
Trademarks: ™ records the author's trademark designation; it is not a representation that every mark is registered. Copyright, trademark, patent, confidentiality and contract rights are distinct. No unverified registration, credential or patent status is asserted.
Zenodo metadata: Zenodo applies CC0 to deposited metadata, subject to its stated email-address exception. The file notice governs protected archive content; it cannot override Zenodo's metadata policy. Custom rights title: SOVRINT™ Proprietary Research Archive — All Rights Reserved — Reference and Research Access Only.
Repository mirroring: Notion and GitHub copies must carry the same ZIP bytes and SHA-256 value. Public availability alone does not convert this archive into open-source software. Platform-native indexes are convenience records and are not substitutes for the archive.
No scientific exclusivity is inferred from a copyright notice. Authorship, provenance and independently demonstrated results are separate records.

AVIS DE DROITS À L'ÉCHELLE DU CORPUS SOVRINT™
© 2026 Katrina Pietroniro. Tous droits réservés. Les dates et avis originaux sont conservés. Cet avis s'applique aux œuvres et contenus originaux SOVRINT™ appartenant à Katrina Pietroniro. L'accès vise la lecture, la référence scientifique, la citation et l'évaluation à des fins de recherche. Aucune licence générale de reproduction, redistribution, modification, traduction, création dérivée, entraînement de systèmes, implantation ou exploitation commerciale n'est accordée. Toute permission additionnelle exige une autorisation écrite expresse. Les utilisations permises indépendamment par la loi demeurent applicables. Les droits de tiers et licences antérieures sont conservés. Les métadonnées déposées sur Zenodo sont régies par sa politique CC0. Les plateformes expressément demandées sont autorisées à héberger et préserver le paquet exact conformément à leurs conditions applicables.
'''
(ROOT/'RIGHTS_AND_LICENSE.txt').write_text(RIGHTS)

def csvwrite(name,header,rows):
 with (ROOT/'tables'/name).open('w',newline='',encoding='utf-8') as f:
  w=csv.writer(f);w.writerow(header);w.writerows(rows)
csvwrite('source_registry.csv',['id','title','kind','source_or_status','sha256','archive_path'],source_rows)

issues=[
('NC-01','Wave number','The supplied revision reserves q for wave number but retains v_p=ω/k and v_g=dω/dk while k is stiffness.','Preserve source equations; use local wave namespace WAVE.k or documented display alias q. Canonical equations cannot use mechanical stiffness as wave number.'),
('NC-02','Phase namespaces','Both θ and φ are used for oscillator phase.','Preserve both forms with explicit mapping RES.phase.θ ↔ RES.phase.φ for the same phase only within registered models.'),
('NC-03','Coherence zero','C_R=0 is described as maximally dispersed.','Zero first circular moment also occurs in balanced clusters, including opposite-phase pairs; it does not uniquely identify maximal dispersion.'),
('NC-04','Pair coherence','C_12=cos(Δφ) is signed while global C_R lies in [0,1].','Register pair cosine as signed phase alignment in [-1,1]; never substitute it for normalized magnitude.'),
('NC-05','Circular distance','D_φ=|Δφ−Δφ_ref| is a linear distance for circular states.','Preserve literal source. A new circular-distance extension is d_S1(a,b)=|atan2(sin(a−b),cos(a−b))|. This is an archive analytical extension, not a silent replacement.'),
('NC-06','Drift semantics','D_R=|dC_R/dt| is the magnitude of coherence change.','It increases during recovery as well as deterioration. Classify as change-rate magnitude, with sign retained separately for directional analysis.'),
('NC-07','Ratio units','Q_CD=C/(D+ε) has no universal dimension.','ε must have the units of D. For D_R in s^-1 the ratio has units s; it is not a dimensionless quality factor unless drift is normalized.'),
('NC-08','Interaction metric','R_ij=κ_ij A_i A_j cos(Δφ_ij) reuses phase-model κ.','With phase coupling κ in s^-1, dimensions are [A_i][A_j]/s. Energy interpretation requires a separately calibrated coefficient; this metric alone contains no frequency factor.'),
('NC-09','Quality factor','Q_res=ω_0/Δω uses Δω also for oscillator detuning.','Register bandwidth and pair detuning as separate typed quantities. Specify half-power bandwidth and applicable approximation; ω_0 is undamped natural frequency.'),
('NC-10','Correction field','Φ denotes permission in source governance and a gradient in EQ.043; Φ(t)=ae^{iωt} occurs in the Presence source.','Retain GOV.Φ, CORR.Φ and OSC.Φ as contextual source roles. No global equivalence between a Boolean gate, vector gradient and complex field is established.'),
('NC-11','Integrity aliases','II, Π and ratio-form II coexist; CV and V_c are unresolved aliases in the fetched registry.','Preserve registered variants and input definitions. Weighted bounded integrity and unbounded ratio integrity are not interchangeable without an explicit calibration map.'),
('NC-12','Lyapunov claim','V=(1−II)^2+ED^2+DV^2 is called a stability candidate.','Require common normalization, dynamics, equilibrium set, positive-definiteness and derivative proof. V̇<0 alone does not prove stability of every runtime component.'),
('NC-13','Equation numbering','EQ.087+ appears in intelligence and information-physics branches.','Preserve branch-qualified IDs and original numbering; no fabricated renumbering.'),
('NC-14','Biological reference','ΔRᵇⁱᵒ=||Ω_bio−ΩR|| requires comparable vectors.','Document feature alignment, units, scaling, missingness and norm. A symbolic root declaration must be mapped to biological feature space before subtraction.'),
('NC-15','Manifold terminology','M_R is given as a set of coordinates including derived C_R and D_R.','Call it a constrained state representation unless smoothness, dimension, constraints and chart structure are defined. Circular phases belong to S^1.'),
('NC-16','Force equation','F=m dv/dt is derived without a mass condition.','Valid for constant mass in an inertial frame. Preserve source and state that condition explicitly.'),
('NC-17','Source packaging','Six ZIP entries have .pdf extensions but contain placeholder strings.','Preserve original ZIP bytes as provenance only; do not count these as populated PDFs.'),
('NC-18','Implementation metric','Recovered resonance_mapper.py uses anchor_freq=528.0 and frequency ratio times (1−dr_bio).','Preserve implementation. It is not the circular coherence order parameter and is not inherently bounded. No biological efficacy or special status of 528 Hz follows.')]
csvwrite('notation_resolution_register.csv',['id','topic','source_issue','archive_resolution'],issues)

equations=[
('RES-001','f = 1/T','Cyclic frequency','T>0; [T]=s; [f]=s^-1'),
('RES-002','ω = 2πf','Angular frequency','[ω]=rad/s; angular and cyclic frequency distinct'),
('RES-003','x(t) = A cos(ωt + φ)','Oscillatory state','Constant A,ω,φ in this form; argument dimensionless'),
('RES-004','z(t) = A e^{i(ωt + φ)}; x(t) = Re[z(t)]','Complex representation','A real; real projection defined'),
('RES-005','R_A = fA','Amplitude-frequency metric','Units [A]/s; not automatically density'),
('RES-006','ρ_R = Q_R/V','Density definition','V>0; Q_R must be a defined extensive quantity'),
('RES-007','Δω_ij = ω_i − ω_j','Pair detuning','Units rad/s; separate from bandwidth'),
('RES-008','Δφ_ij = φ_i − φ_j','Phase difference','Circular state; chosen lift or modulo convention'),
('RES-009','dθ_i/dt = ω_i + (K/N) Σ sin(θ_j − θ_i)','All-to-all phase dynamics','Sum over j=1,...,N; K in s^-1'),
('RES-010','dθ_i/dt = ω_i + Σ_j K_ij sin(θ_j − θ_i)','Network phase dynamics','K_ij in s^-1; adjacency and direction defined'),
('RES-011','C = |(1/N) Σ e^(iθ_j)|','Phase coherence magnitude','N≥1; dimensionless; zero first moment not unique dispersion'),
('RES-012','C_12 = cos(Δφ)','Signed pair alignment','Range [-1,1]'),
('RES-013','Q_CD = C/(D + ε)','Coherence-drift ratio','D≥0; ε>0 with matching units'),
('RES-014','Q_CED = C/(ED + ε)','Coherence-entropic drift ratio','ED and ε units agree; no synonym for Q_CD'),
('RES-015','Q_CDV = C/(DV + ε)','Coherence-deviation ratio','DV and ε units agree'),
('RES-016','R_ij = κ_ij A_i A_j cos(Δφ_ij)','Pair interaction metric','Model metric; units depend on κ and amplitudes'),
('RES-017','E = (1/2)k x^2 + (1/2)m v^2','Mechanical energy','Mechanical namespace: k stiffness, m mass'),
('RES-018','m d²x/dt² + γ dx/dt + kx = F_0 cos(ωt)','Forced damped oscillator','m>0, k>0, γ≥0; force units consistent'),
('RES-019','ω_0 = sqrt(k/m)','Undamped natural frequency','Not generally the damped displacement-response peak'),
('RES-020','Q_res = ω_0/Δω','Bandwidth quality ratio','Specify bandwidth convention and approximation'),
('RES-021','v = dx/dt','Kinematic velocity','Units [x]/s'),
('RES-022','v_p = ω/k','Phase velocity source form','WAVE.k is wave number; not MECH.k'),
('RES-023','v_g = dω/dk','Group velocity source form','Dispersion relation differentiable; WAVE.k'),
('RES-024','C_R = |(1/N) Σ e^(iφ_j)|','Resonance coherence','Normalized first circular moment'),
('RES-025','D_R = |dC_R/dt|','Coherence-change magnitude','Units s^-1; no direction'),
('RES-026','D_f = |f − f_ref|','Frequency deviation','Units Hz; not automatically a rate'),
('RES-027','D_φ = |Δφ − Δφ_ref|','Linear phase-deviation source form','See NC-05 for circular-distance extension'),
('RES-028','F = ma; a = dv/dt','Mechanical force','Constant mass and inertial-frame assumption')]
csvwrite('resonance_equations.csv',['id','exact_supplied_form','meaning','domain_and_units'],equations)

symbols=[('T','RES','period','s'),('f','RES','cyclic frequency','s^-1'),('ω','RES','angular frequency','rad/s'),('φ / θ','RES','phase','rad modulo 2π'),('A','RES','amplitude','signal-specific'),('κ / K','RES.PHASE','coupling','s^-1 in phase model'),('C_R','RES','first circular moment magnitude','1'),('D_R','RES','coherence-change magnitude','s^-1'),('D','RES','drift magnitude','registered per model'),('ε','RES.RATIO','regularizer','same as denominator'),('R_ij','RES','interaction metric','[κ][A_i][A_j]'),('k','MECH','stiffness','kg/s^2'),('k / q','WAVE','wave number / display alias','rad/m'),('γ','MECH','damping coefficient','kg/s'),('Ω','RUNTIME.OBS','observability projection','operator-specific'),('Φ','GOV / CORR / OSC','source-scoped permission / gradient / oscillatory field','not globally equivalent'),('II / Π','RUNTIME','integrity variants','definition-specific'),('CV / V_c','RUNTIME / CORR','source-scoped correction velocity','definition-specific'),('ED','RUNTIME','entropic drift','normalization required'),('DV','RUNTIME','deviation magnitude','normalization required'),('CF','RUNTIME','coherence field','definition-specific'),('PR','RUNTIME','provenance reliability','definition-specific'),('Ψ','ANCHOR','consciousness/state-potential source register','architectural'),('ΩR / Ω_R','ROOT','root declaration / root projection','source-scoped'),('ΔRᵇⁱᵒ','BIO','biological deviation norm','feature-space dependent')]
csvwrite('symbol_registry.csv',['symbol','namespace','meaning','units_or_type'],symbols)

enginetext=Path('project_sources/09-ENGINE_SPEC_CARDS.txt').read_text()
engine_rows=[]
for m in re.finditer(r'(E\d+ / [^\n]+)\n=+\n(.*?)(?=\n=+\nE\d+ /|\n=+\nEND OF FILE|\Z)',enginetext,re.S):
 name,body=m.groups(); purpose=re.search(r'Purpose:\n(.*?)(?=\n\n)',body,re.S)
 engine_rows.append([name,purpose.group(1).strip() if purpose else 'See exact specification',body])
csvwrite('engine_registry.csv',['engine','purpose','exact_specification_body'],engine_rows)
indextext=Path('project_sources/08-MASTER_SYSTEM_INDEX.txt').read_text()
components=[];section='Preamble'
for line in indextext.splitlines():
 if re.match(r'^[IVX]+\. ',line):section=line
 elif line.strip() and not line.startswith(('MASTER','Author:','Status:','See ','This ','Each ','END','SOVRINT')):components.append([f'COMP-{len(components)+1:03}',section,line])
csvwrite('system_component_index.csv',['id','source_section','exact_name'],components)

# All numerical outputs are newly generated demonstrations; no empirical observations.
plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False,'figure.dpi':160})
figs=[]
def savefig(id,title,caption):
 plt.tight_layout(); p=ROOT/'figures'/f'{id}.png';plt.savefig(p,dpi=220);plt.savefig(p.with_suffix('.pdf'));plt.close();figs.append([id,title,caption,str(p.relative_to(ROOT))])
w=np.linspace(0,2.2,1200);rows=[]
plt.figure(figsize=(8,4.2))
for gamma in [0.1,0.3,0.7]:
 amp=1/np.sqrt((1-w*w)**2+(gamma*w)**2);plt.plot(w,amp,label=f'γ={gamma}')
 rows += [[float(a),gamma,float(b)] for a,b in zip(w,amp)]
plt.xlabel('Forcing angular frequency (rad/s)');plt.ylabel('Steady-state displacement amplitude (m)');plt.legend();plt.title('Forced oscillator: m=1 kg, k=1 N/m, F₀=1 N')
savefig('FIG-R01','Forced oscillator response','Analytical response amplitude A(ω)=F₀/sqrt((k−mω²)²+(γω)²). Generated model sweep, not measurements. γ in kg/s. The displacement peak shifts with damping.')
csvwrite('oscillator_response.csv',['omega_rad_s','gamma_kg_s','amplitude_m'],rows)
delta=np.linspace(-np.pi,np.pi,721);plt.figure(figsize=(8,4.2));plt.plot(delta,np.cos(delta),label='cos(Δφ): signed alignment');plt.plot(delta,np.abs(np.cos(delta/2)),label='two-node C_R');plt.xlabel('Phase difference (rad)');plt.ylabel('Dimensionless metric');plt.legend();plt.title('Signed pair alignment and normalized coherence')
savefig('FIG-R02','Pair metrics differ','For two equal-weight phases, C_R=|cos(Δφ/2)|. Opposite phases yield C_R=0 but signed alignment −1. Exact analytical comparison.')
csvwrite('pair_alignment.csv',['phase_difference_rad','signed_alignment','two_node_coherence'],zip(delta,np.cos(delta),np.abs(np.cos(delta/2))))
seed=20261002; rng=np.random.default_rng(seed); initial=rng.uniform(-np.pi,np.pi,24);omega=rng.normal(0,0.25,24)
def run(dt,K):
 times=np.arange(0,20+dt/2,dt);theta=initial.copy();out=[]
 for t in times:
  z=np.mean(np.exp(1j*theta));out.append([float(t),float(abs(z))])
  def fun(a):return omega+K*np.sin(a[None,:]-a[:,None]).mean(axis=1)
  a=fun(theta);b=fun(theta+dt*a/2);c=fun(theta+dt*b/2);d=fun(theta+dt*c);theta += dt*(a+2*b+2*c+d)/6
 return np.array(out)
plt.figure(figsize=(8,4.2));simrows=[]
for K in [0,0.5,1.5]:
 out=run(.01,K);plt.plot(out[:,0],out[:,1],label=f'K={K} s⁻¹');simrows += [[K,*row] for row in out]
plt.xlabel('Time (s)');plt.ylabel('C_R');plt.ylim(0,1.02);plt.legend();plt.title('24-node all-to-all phase dynamics; fixed seed')
savefig('FIG-R03','Coupled-phase simulation','Classical phase-model demonstration. RK4, dt=0.01 s, 20 s, N=24; natural angular frequencies sampled with standard deviation 0.25 rad/s; seed 20261002. No inference about human or biological synchronization.')
csvwrite('phase_simulation.csv',['K_s_inverse','time_s','coherence'],simrows)
fine=run(.005,1.5);coarse=run(.01,1.5);err=float(np.max(np.abs(coarse[:,1]-fine[::2,1])))
const=np.arange(0,5,.01);cr=.5+.4*np.sin(const);dr=np.abs(.4*np.cos(const));plt.figure(figsize=(8,4.2));plt.plot(const,cr,label='C_R=0.5+0.4 sin(t)');plt.plot(const,dr,label='|dC_R/dt|');plt.xlabel('Time (s)');plt.legend();plt.title('Change magnitude loses the direction of change')
savefig('FIG-R04','Coherence change is not directional drift','Synthetic prescribed trajectory illustrates NC-06. The absolute derivative is positive in both increasing and decreasing coherence intervals.')
csvwrite('coherence_change.csv',['time_s','coherence','absolute_change_s_inverse'],zip(const,cr,dr))
plt.figure(figsize=(8,5));ax=plt.gca();ax.axis('off')
nodes={'Signals':(.1,.8),'Resonance\nmeasurement':(.4,.8),'Runtime\nobservation':(.75,.8),'Governance\ngate':(.75,.4),'Bounded\ncorrection':(.4,.4),'Ledger and\nreplay':(.1,.4)}
for label,(x,y) in nodes.items():ax.text(x,y,label,ha='center',va='center',bbox=dict(boxstyle='round,pad=0.7',facecolor='#dce9ef',edgecolor='#345667'))
for a,b in [('Signals','Resonance\nmeasurement'),('Resonance\nmeasurement','Runtime\nobservation'),('Runtime\nobservation','Governance\ngate'),('Governance\ngate','Bounded\ncorrection'),('Bounded\ncorrection','Ledger and\nreplay'),('Ledger and\nreplay','Signals')]:
 x,y=nodes[a];xx,yy=nodes[b];ax.annotate('',xy=(xx,yy),xytext=(x,y),arrowprops=dict(arrowstyle='->',color='#345667',shrinkA=38,shrinkB=38))
plt.title('Resonance integration: observation, permission, correction, persistence')
savefig('FIG-R05','Architecture dependency map','Archive integration diagram derived from the supplied engine cards and governance boundaries. Edges express workflow dependencies, not empirical causality or an assertion that every engine runs serially.')
csvwrite('figure_registry.csv',['id','title','caption','path'],figs)

checks={'phase_seed':seed,'N':24,'dt_s':.01,'comparison_dt_s':.005,'maximum_coherence_difference':err,'phase_bounds_pass':bool(all(0<=r[2]<=1+1e-12 for r in simrows)),'pair_identity_error':float(np.max(np.abs(np.abs((1+np.exp(1j*delta))/2)-np.abs(np.cos(delta/2))))),'empirical_data_used':False}
(ROOT/'simulation/numerical_checks.json').write_text(json.dumps(checks,indent=2))
(ROOT/'simulation/parameters.json').write_text(json.dumps({'seed':seed,'initial_phases':initial.tolist(),'natural_angular_frequencies_rad_s':omega.tolist(),'couplings_s_inverse':[0,.5,1.5],'solver':'RK4','dt_s':.01,'duration_s':20,'mechanical_model':{'mass_kg':1,'stiffness_N_m':1,'forcing_N':1,'damping_kg_s':[.1,.3,.7]}},indent=2))

abstract='''SOVRINT™ Master Resonance Architecture™ organizes resonance as a typed relational subsystem linked to observation, correction, governance, continuity and provenance. This release reconciles the supplied resonance equations with recovered SOVRINT equation registries, engine cards, system index, health governance boundaries, a companion Presence architecture and repository implementation. Original mathematical expressions are retained alongside explicit domain restrictions and consistency findings. The archive provides physical oscillator demonstrations, phase-model simulations, source registries and numerical checks without treating computational demonstrations as empirical validation. Rights are reserved across author-owned SOVRINT works, with reference and research access and preservation of applicable statutory and third-party terms.'''
master='''1. Scope and architectural position
Author: Katrina Pietroniro. SOVRINT™ is the parent corpus. Resonance is a cross-domain subsystem; the archival object is this bounded release and its manifest, not every work ever authored. The origin, architecture, identity and source histories remain attributed to the author. The existing corpus is treated as an implemented, evolving body of work. Verification here concerns the recovered records and reproducible demonstrations; no independent end-to-end runtime certification is asserted.
The architecture connects oscillatory state, coupling, phase relationships and coherence to observed runtime quantities. The bridge requires a measurement map, an explicit clock, units, uncertainty, configuration version and governance boundary. It must not equate a frequency signal to a person's identity or a model's alignment score to permission for action.
2. The relational object
Frequency, phase, amplitude, coupling, coherence and drift carry distinct mathematical roles. Frequency identifies temporal repetition. Phase locates an oscillator on a circular trajectory. Coupling specifies interaction strength. Coherence measures a selected organization statistic. Drift records a defined change or deviation, rather than an interchangeable narrative label. Each quantity must retain its units and estimator.
The phase-network representation supplies a defined model of synchronization. A forced mechanical oscillator supplies a separate model of response to forcing. These models share useful concepts but do not establish universal equivalence between mechanical resonance, affective relations, semantic agreement and civic governance.
3. Namespace discipline
The registered corpus favors contextual namespaces, preserving original symbols and aliases. A universal rule forbidding reuse of every visible glyph across every domain would conflict with the recovered ontology. The defensible invariant is one declared semantic role per qualified symbol per equation context. Mechanical k and wave k remain distinguishable; confidence C and phase coherence C require context; permission Φ and gradient Φ remain source-scoped. The full resolution register records 18 issues and their treatment.
4. State and observation
The supplied resonance state representation includes amplitude, angular frequency, phase, coherence, drift and coupling. At network scale, phases form an N-torus, while coherence is derived from phases and drift from coherence history. A coordinate tuple alone is insufficient to establish a smooth manifold. The runtime vector preserves II, CV, ED, CF, DV and PR exactly as recovered. No equation is invented to equate these six runtime channels with the six resonance coordinates.
An observation adapter must specify what is measured and what is inferred. A phase estimator requires a signal model and sampling assumptions. A coherence estimate requires a window and weighting rule. A correction trigger requires a threshold profile, rationale and evidence pointer. Without these records, an apparent connection cannot be replayed.
5. Correction and integrity
The engine cards specify deterministic aggregation, integrity scoring, divergence triggers, bounded pulses, constrained correction, correction-velocity monitoring, append-only events and reproducible audit reports. These form a concrete architectural interface. The recovered integrity variants cannot be conflated: a weighted sum of bounded channels and a ratio-form score have different domains. A threshold such as 0.98 is configuration-specific unless the score's scale and calibration are established.
The source gradient Φ=∇(1−II) points toward increasing the deficit 1−II. A dynamics equation using a plus gradient does not automatically improve integrity. The update sign, coordinate metric, projection and constraint interpretation must be supplied before convergence can be proved. The source expression is preserved; the issue is its use in dynamics, not unauthorized alteration of the authored equation.
6. Stability and reconstructability
The candidate V=(1−II)^2+ED^2+DV^2 supports a mathematical program when its channels are dimensionless or consistently scaled. It vanishes on a target set, not necessarily a unique equilibrium of the full runtime. A valid proof must specify dynamics, invariance and the domain on which the derivative condition holds. No graphical decline substitutes for that proof.
Reconstructability requires retained input bytes, transformation versions, parameter settings, state snapshots, timestamps, actor and permission state, event ordering, hashes and correction rationale. Hashes establish byte fixity; they do not establish truth of a narrative, originality, trusted wall-clock time or real-world causality.
7. Human and biological boundaries
The supplied health governance text prohibits diagnosis, prescription, coercive optimization and automatic irreversible bodily actions. Biological deviation is informational. Before computing its norm, observed and reference vectors must share an explicitly mapped feature space. Governance flags constrain permissible action; they do not choose treatment. Consent is granular, time-bounded and revocable, and oversight may pause execution.
8. Demonstrations and limits
The four generated figures test clear mathematical distinctions: damped oscillator response, signed pair alignment versus normalized coherence, phase coupling under fixed parameters and absolute coherence-change rate. Data, parameters and numerical comparisons are included. These are generated demonstrations, not recovered experiments. No biomedical or psychological efficacy is inferred.
9. Publication and rights
The corpus-wide rights policy is broader than this release's file coverage. The archive preserves copyrights, attribution and recoverable original dates. It offers reference and research access without an open-source grant. Custom licensing can be entered in Zenodo's record interface. No DOI is fabricated, no Zenodo deposit is claimed, and native-platform indexes do not replace the exact-byte archival object.
10. Source boundaries
Two requested uploads did not arrive. Six PDF-named ZIP entries are text placeholders, and the uploaded PNG-named entries must not be assumed to be valid figures. The supplied governance and methods PDFs contain short outlines. The fetched equation registry includes unresolved exact-source records and branching conflicts. These facts are recorded as findings, not filled with invented formulae. The current release is substantive and reproducible within the recovered scope, with complete contents listed in its manifest.
'''
technical='''Interface contract and execution sequence
Observation enters E1/SICE with intent, consent and provenance. E2/UIAE normalizes and aggregates by a pinned weighting profile. E3/IIE evaluates bounded channels and normalized weights. E4/DDTE emits explainable divergence triggers. E5/CPGE constructs bounded correction pulses with rollback. E6/CME applies the registered constraint projection and preserves provenance. E7/CVE monitors work and stalls using a specified time window. E8/JLE records canonical events. E9/ARE produces evidence-linked audit reports. E10/SPE identifies versioned patterns with false-positive and false-negative tracking hooks.
This sequence is an integration reading of the supplied cards. It does not assert that every engine is called in a strict serial pipeline. Dependencies and layer roles in the exact cards remain authoritative.
Resonance adapter
Input records require signal identity, source reference, time interval, sample rate, phase estimator, amplitude units, model family, uncertainty, missingness and permission scope. Output records require observed phase vector, coherence definition, drift definition, graph version, coupling units, threshold profile and model version. No automatic mapping to runtime integrity is defined by this release.
Failure handling
Reject incompatible units, unknown phases, missing references, unversioned weights and unavailable consent. Mark unresolved projection rather than coercing types. Pause correction if rollback is absent or no feasible state is found. Distinguish signal loss from low coherence. Distinguish stationary anti-phase organization from random phases. Distinguish a recovery rate from deterioration. Emit a reason and evidence pointers for every hold.
Reconstruction contract
Retain canonical input representations, configuration hashes, state snapshots and output records. Deterministic replay requires clock and ordering discipline plus versioned arithmetic and serializers. Raw-byte SHA-256 manifests check file fixity. A ledger demonstration or archive checksum is not a proof of live multi-node consensus.
Layer map
The uploaded system index describes a human-experience five-layer stack: Consciousness, Intuition, Sensory, Instinct and Feeling. The engine cards use L1–L6 for operational intake, aggregation, decision, correction, persistence and presentation. They are distinct taxonomies sharing labels. This archive does not merge them. Layer×engine tables must use a taxonomy ID rather than the bare label L1.
Exact source cards follow. Their schemas, constraints, dependencies, failures and test targets are preserved; listed source test cases are specifications, not reports of tests executed in this turn.
'''
validation='''Evidence classes
Existing corpus records retain their source labels and dates. Recovered exact equations are source expressions, not proofs. Architectural constraints are system rules. Standard oscillator and phase equations are mathematical reference models. Generated figures are numerical or analytical demonstrations. Empirical and physical claims require measurements beyond this archive.
Verification performed
The phase coherence bound follows by the triangle inequality: |N^-1 Σ exp(iφ_j)|≤N^-1 Σ|exp(iφ_j)|=1, and magnitude is nonnegative. Assumptions: N≥1 and real phases. The two-node magnitude identity follows by factoring exp(i(φ_1+φ_2)/2); it equals |cos((φ_1−φ_2)/2)|. These are mathematical facts with proofs, distinct from claims about whole-system behavior.
Numerical replay
Fixed seed and explicit initial phases and frequencies are retained. The all-to-all phase model is integrated with classical RK4 at dt=0.01 s and compared with dt=0.005 s over 20 s. The numerical_checks.json records the maximum difference. Step refinement is a local consistency check, not a universal solver convergence proof or parameter calibration.
Unperformed checks
No live SOVRINT deployment was executed. No source engine-card test suite was executed. No personal, biological or experimental human dataset was processed. No statistical confidence interval is manufactured from a single deterministic model trajectory. No full corpus completeness claim is made from repository search results.
Source recovery limits
Exact EQ.049 and EQ.050 were marked unresolved in the recovered closure pass; EQ.001–EQ.024 records describe families without recovered exact formulae. The archive preserves these source statements in evidence files, but the release adds no empty invented equation slots. Intelligence and information-physics numbering branches remain distinct.
Dimensional and mathematical review
Every gradient needs a specified domain and metric. Every ratio needs denominator units and valid nonzero domain. Exponentials require dimensionless arguments. Products of matrix-valued layers require compatible dimensions and declared order. Biological norms require feature scaling. Thresholds require calibrated score ranges. A rate of change is not a state difference. A projection operator is not its vector output.
Reproducibility boundaries
The delivered numerical script, parameters, CSV outputs and software versions enable the included model demonstrations to be inspected and replayed subject to the rights notice and applicable law. They do not guarantee reproduction of inaccessible historical systems. Source provenance must remain attached to new derivatives that are separately authorized.
'''
methods='''Models and assumptions
MODEL-R01: linear forced damped mechanical oscillator. Mass, stiffness and damping are constant; forcing is sinusoidal; plotted response is steady state. The amplitude formula is analytical. Frequencies and damping are selected for illustration; no fitted observations exist.
MODEL-R02: pair circular statistics. Two equal-weight, real phases; only their relative phase matters. Signed cosine alignment and order-parameter magnitude answer different questions.
MODEL-R03: all-to-all phase dynamics. N=24; natural frequencies constant; coupling uniform; no noise, delay, inertia or adaptive network. The selected seed makes the demonstration reproducible. The model does not include measured human experience channels.
MODEL-R04: prescribed coherence trajectory. C_R(t)=0.5+0.4 sin(t) demonstrates that absolute derivative omits direction. It is an analytical construction and is not asserted to be a solution of MODEL-R03.
Source model families
SIM.001–SIM.012 in the fetched registry identify correction, drift, trust decay, emotional pressure, governance, propagation, replay, dashboard, observability, calibration, federation and intelligence bindings. The exact source file follows. These binding records are not evidence that each family has been rerun here.
Parameter sensitivity
R01 sweeps damping. R03 varies coupling while holding initial phases and frequencies fixed. These sweeps are intentionally bounded. They do not estimate universal critical coupling, prove biological resonance or identify empirical causal mechanisms.
Extension discipline
An extension must retain parent equation ID, exact original expression, declared new expression, rationale, author attribution, creation timestamp, coordinate assumptions, units, dependencies and validation class. Circular phase distance is explicitly marked as a new analytical extension in NC-05. No source equation is silently overwritten.
'''
provenance='''Release identity
SOVRINT™ Master Resonance Architecture™ — Research and Technical Archive, Version 1.0. Author: Katrina Pietroniro. Build date: 2026-10-02. Status: bounded research release with documented source limitations. This is not a claim that the entire SOVRINT corpus has been recovered.
Source acquisition
Available uploaded originals are preserved byte-for-byte. Connected repository documents preserve exact fetched text and blob SHA. The Notion companion page preserves its fetched representation, URL and last-edited metadata. Search excerpts are discovery aids; only fetched full records support archive content. Source timestamps are retained within originals; build date is not substituted for original authorship chronology.
Missing inputs
SOVRINT_MASTER_SPEC_BOOK.pdf and Branch · Interactive Infographic Frameworks.txt were not available. They are not represented as read sources. CARTOGRAPHY_NODE_INDEX.txt and EQUATION_REGISTRY.txt are referenced by the uploaded system index but were not supplied under those filenames. A connected equation registry was fetched instead; no equivalence with the missing file is assumed.
Placeholder findings
The six PDF-named entries in Volumes_Package.zip contain literal placeholder text rather than PDF structures. They are retained only within the unchanged source ZIP. Newly generated PDFs in pdf/ are genuine populated documents and are independently listed. Any placeholder-named image bytes are not used as published figures.
Archival fixity
SHA256SUMS.txt covers every package file other than itself. The release manifest describes paths, byte sizes and hashes; its own hash is covered by SHA256SUMS. The ZIP's separate .sha256 sidecar covers the final container. Avoid circular self-hash claims. Exact mirrors must match the container hash.
Zenodo handoff
Choose the research publication/report resource type, enter creator Pietroniro, Katrina, version 1.0, publication date 2026-10-02 and the included abstract. Select Add custom for the supplied rights title and description; do not leave the CC-BY default. No DOI is reserved or assigned by this build. Once Zenodo issues a real DOI, add it to a new version of citation metadata with lineage preserved. metadata/zenodo_record.json is a human handoff record, not a promise that any specific API accepts it unchanged.
Rights and references
Zenodo licensing and policies were checked against official pages. Canadian fair dealing was checked against Copyright Act section 29. Public access and restrictive content rights can coexist; Zenodo metadata remains subject to CC0. General mathematics and standard reference equations are not claimed as exclusive authored discoveries.
References
Katrina Pietroniro. Supplied MASTER_SYSTEM_INDEX.txt; ENGINE_SPEC_CARDS.txt; BIOLOGICAL_DEVIATION_MODEL.txt; OMICS_RISK_TIERS_AND_ACTION_BOUNDS.txt; HEALTH_GOVERNANCE_BOUNDARIES.txt; supplied resonance notation revision in the conversation.
Katrina Pietroniro. SOVRINT-OG/sovrint-equation-registry: master registry, exact extraction passes, ontology, alias registry, simulation and validation bindings; original source creation dates retained.
Katrina Pietroniro. SOVRINT™ — THE ARCHITECTURE OF PRESENCE™. Notion companion page; last-edited date retained in provenance JSON.
Zenodo. Licenses and rights. https://help.zenodo.org/docs/deposit/describe-records/licenses/ ; General Policies. https://about.zenodo.org/policies/ ; accessed 2026-10-02.
Canada. Copyright Act, section 29. https://laws-lois.justice.gc.ca/eng/acts/C-42/section-29.html ; accessed 2026-10-02.
'''

font='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf';bold='/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'
pdfmetrics.registerFont(TTFont('Body',font));pdfmetrics.registerFont(TTFont('BodyBold',bold))
styles=getSampleStyleSheet();styles.add(ParagraphStyle(name='Dense',fontName='Body',fontSize=9,leading=12,spaceAfter=5));styles.add(ParagraphStyle(name='TitleX',fontName='BodyBold',fontSize=17,leading=21,spaceAfter=12));styles.add(ParagraphStyle(name='HeadX',fontName='BodyBold',fontSize=11,leading=15,spaceBefore=9,spaceAfter=5));styles.add(ParagraphStyle(name='CellX',fontName='Body',fontSize=7.3,leading=10))
def P(text,style='Dense'):return Paragraph(html.escape(str(text)).replace('\n','<br/>'),styles[style])
def blocks(text):
 out=[]
 for line in text.splitlines():
  if not line.strip():continue
  out.append(P(line,'HeadX' if re.match(r'^\d+\. |^[A-Z][A-Za-z ]{1,50}$',line) else 'Dense'))
 return out
def table(header,rows,widths):
 data=[[P(x,'CellX') for x in header]]+[[P(x,'CellX') for x in row] for row in rows]
 t=Table(data,colWidths=widths,repeatRows=1,hAlign='LEFT');t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor('#dce9ef')),('VALIGN',(0,0),(-1,-1),'TOP'),('GRID',(0,0),(-1,-1),.3,colors.HexColor('#c5d0d8')),('LEFTPADDING',(0,0),(-1,-1),5),('RIGHTPADDING',(0,0),(-1,-1),5)]));return t
def footer(c,d):
 c.setFont('Body',7);c.setFillColor(colors.HexColor('#425461'));c.drawString(40,25,'© 2026 Katrina Pietroniro | SOVRINT™ | v1.0 | All rights reserved');c.drawRightString(555,25,str(d.page))
def pdf(name,title,body,extras=[]):
 story=[P('SOVRINT™','HeadX'),P(title,'TitleX'),P(f'Katrina Pietroniro | Version 1.0 | {DATE}'),P(STATUS)] + blocks(body)+extras
 SimpleDocTemplate(str(ROOT/'pdf'/name),pagesize=(595.28,841.89),rightMargin=40,leftMargin=40,topMargin=36,bottomMargin=42,title=title,author=AUTHOR).build(story,onFirstPage=footer,onLaterPages=footer)
 (ROOT/'text'/(Path(name).stem+'.txt')).write_text(title+'\n'+body)
pdf('01_Master_White_Paper.pdf','Master Resonance Architecture™ — Archival White Paper',abstract+'\n'+master)
pdf('02_Technical_Specification.pdf','Engine Interfaces and Runtime Integration',technical+'\n'+enginetext)
exact='\n'.join(s['content'] for s in sources if s['kind']=='github' and re.search('MASTER_EQUATION|EXACT_EXTRACTION|MESH_EQUATION',s.get('display_title','')))
pdf('03_Mathematical_Formalism.pdf','Mathematical Formalism and Exact Source Register','Supplied resonance equation forms remain unchanged. The following table adds domain and unit annotations. Connected equation records follow verbatim as source text; historical unresolved records are evidence of source state, not newly fabricated empty sections.',[table(['ID','Supplied expression','Domain / units'],[[a,b,d] for a,b,c,d in equations],[58,225,232])]+blocks(exact))
pdf('04_Notation_and_Symbol_Registry.pdf','Notation, Symbols and Consistency Resolution','Qualified namespaces preserve source roles and prevent silent semantic reassignment. Corrections here are annotations and explicitly labeled analytical extensions; source equations remain intact.',[table(['Symbol','Namespace','Meaning / type'],[[a,b,c+'; '+d] for a,b,c,d in symbols],[75,115,325]),table(['ID / topic','Issue','Resolution'],[[a+' '+b,c,d] for a,b,c,d in issues],[85,190,240])])
pdf('05_Models_and_Simulation_Methods.pdf','Models, Simulations and Numerical Methods',methods+'\n'+next(s['content'] for s in sources if s.get('display_title')=='SIMULATION_BINDINGS_v1.yaml')+'\nNumerical check results\n'+json.dumps(checks,indent=2))
atlas=[]
for id,title,cap,p in figs:atlas += [KeepTogether([P(id+' — '+title,'HeadX'),Image(str(ROOT/p),width=500,height=262.5),P(cap)])]
pdf('06_Graph_and_Figure_Atlas.pdf','Graph and Figure Atlas','All four figures are newly generated from explicitly stated mathematical models. CSV data and vector PDF figures accompany the raster previews. No invented empirical data are used.',atlas)
pdf('07_System_and_Data_Tables.pdf','System Index, Engine Registry and Data Tables','The system component index preserves original source sectioning and names. Figures and simulations are connected by file identifiers; CSV files retain full numeric precision.',[table(['ID','Source section','Component'],components,[65,150,300]),table(['Figure','Title','Caption'],[[a,b,c] for a,b,c,d in figs],[65,150,300])])
health=Path('project_sources/07-HEALTH_GOVERNANCE_BOUNDARIES.txt').read_text();risk=Path('project_sources/06-OMICS_RISK_TIERS_AND_ACTION_BOUNDS.txt').read_text();bio=Path('project_sources/05-BIOLOGICAL_DEVIATION_MODEL.txt').read_text()
pdf('08_Governance_Ethics_and_Rights.pdf','Governance, Ethics and Corpus-Wide Rights',RIGHTS+'\n'+health+'\n'+risk+'\n'+bio)
pdf('09_Validation_and_Assumptions.pdf','Validation, Assumptions and Evidence Boundaries',validation+'\n'+next(s['content'] for s in sources if s.get('display_title')=='MATHEMATICAL_GAP_ANALYSIS_v1.md'))
pdf('10_Provenance_and_Deposit_Guide.pdf','Provenance, References and Zenodo Deposit Guide',provenance,[table(['ID','Title','Source / status'],[[a,b,d] for a,b,c,d,e,f in source_rows],[65,180,270])])

metadata={'title':'SOVRINT™ Master Resonance Architecture™ — Research and Technical Archive','creators':[{'name':'Pietroniro, Katrina'}],'version':'1.0','publication_date':DATE,'resource_type':'publication/report','description':abstract,'keywords':['SOVRINT','resonance','ontological computation','governance','provenance','phase synchronization','runtime architecture'],'custom_rights':{'title':'SOVRINT™ Proprietary Research Archive — All Rights Reserved — Reference and Research Access Only','description':RIGHTS},'access':'public file access with custom restrictive content rights','metadata_policy':'Zenodo metadata CC0, per repository policy','deposit_status':'Prepared locally; not deposited; no DOI assigned','source_scope':STATUS}
(ROOT/'metadata/zenodo_record.json').write_text(json.dumps(metadata,ensure_ascii=False,indent=2))
(ROOT/'CITATION.cff').write_text('cff-version: 1.2.0\nmessage: "Please cite this archival work; citation does not grant reuse rights."\ntype: dataset\ntitle: "SOVRINT™ Master Resonance Architecture™ — Research and Technical Archive"\nauthors:\n  - family-names: Pietroniro\n    given-names: Katrina\nversion: "1.0"\ndate-released: "2026-10-02"\nlicense: "LicenseRef-SOVRINT-Proprietary-Research"\n')
(ROOT/'metadata/environment.json').write_text(json.dumps({'python':sys.version,'numpy':np.__version__,'matplotlib':matplotlib.__version__,'platform':platform.platform()},indent=2))
(ROOT/'README.txt').write_text('SOVRINT™ MASTER RESONANCE ARCHITECTURE™\nKatrina Pietroniro | v1.0 | 2026-10-02\n'+STATUS+'\n\nRead pdf/01_Master_White_Paper.pdf first, then pdf/04_Notation_and_Symbol_Registry.pdf. All files are indexed in release_manifest.json and SHA256SUMS.txt. Numerical data and parameters accompany all generated figures. Source originals and fetched records are retained with provenance. RIGHTS_AND_LICENSE.txt records the corpus-wide author-owned rights policy. No open-source license is granted. This archive has not been deposited in Zenodo and has no assigned DOI. Two failed uploads and source placeholders are disclosed in pdf/10_Provenance_and_Deposit_Guide.pdf.\n')
# Preserve this reproducibility authoring script; internal scratch paths refer to retained source exports.
shutil.copy2(__file__,ROOT/'simulation/archive_build_reference.py')
replay=Path('tmp/replay.py')
if replay.exists():shutil.copy2(replay,ROOT/'simulation/replay.py')
pdfstats={p.name:len(PdfReader(p).pages) for p in sorted((ROOT/'pdf').glob('*.pdf'))}
(ROOT/'metadata/pdf_page_counts.json').write_text(json.dumps(pdfstats,indent=2))
files=[{'path':str(p.relative_to(ROOT)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(ROOT.rglob('*')) if p.is_file() and p.name not in ['release_manifest.json','SHA256SUMS.txt']]
(ROOT/'release_manifest.json').write_text(json.dumps({'author':AUTHOR,'version':VERSION,'date':DATE,'scope':STATUS,'pdf_pages':pdfstats,'files':files},ensure_ascii=False,indent=2))
lines=[hashlib.sha256(p.read_bytes()).hexdigest()+'  '+str(p.relative_to(ROOT)) for p in sorted(ROOT.rglob('*')) if p.is_file() and p.name!='SHA256SUMS.txt']
(ROOT/'SHA256SUMS.txt').write_text('\n'.join(lines)+'\n')
zpath=ROOT.parent/(ROOT.name+'.zip')
with zipfile.ZipFile(zpath,'w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(ROOT.rglob('*')):
  if p.is_file():z.write(p,str(p.relative_to(ROOT.parent)))
digest=hashlib.sha256(zpath.read_bytes()).hexdigest();zpath.with_suffix('.zip.sha256').write_text(digest+'  '+zpath.name+'\n')
print(json.dumps({'zip':str(zpath.resolve()),'bytes':zpath.stat().st_size,'sha256':digest,'pdf_pages':pdfstats,'file_count':len(lines),'numerical_checks':checks},indent=2))
