"""SOVRINT archive demonstration replay. © 2026 Katrina Pietroniro.
All rights reserved. See ../RIGHTS_AND_LICENSE.txt and applicable law.
Run from any directory: python simulation/replay.py
Reads retained parameters; checks delivered phase-model CSV without modifying it.
"""
from pathlib import Path
import json,csv
import numpy as np
root=Path(__file__).resolve().parents[1]
p=json.loads((root/'simulation/parameters.json').read_text())
initial=np.array(p['initial_phases']);omega=np.array(p['natural_angular_frequencies_rad_s'])
expected=np.loadtxt(root/'tables/phase_simulation.csv',delimiter=',',skiprows=1)
max_error=0.0
for K in p['couplings_s_inverse']:
 theta=initial.copy();dt=p['dt_s'];rows=[]
 def fun(a):return omega+K*np.sin(a[None,:]-a[:,None]).mean(axis=1)
 for t in np.arange(0,p['duration_s']+dt/2,dt):
  rows.append([K,t,abs(np.mean(np.exp(1j*theta)))])
  a=fun(theta);b=fun(theta+dt*a/2);c=fun(theta+dt*b/2);d=fun(theta+dt*c)
  theta += dt*(a+2*b+2*c+d)/6
 actual=np.array(rows);saved=expected[expected[:,0]==K]
 assert actual.shape==saved.shape
 max_error=max(max_error,float(np.max(np.abs(actual-saved))))
assert max_error<1e-10,max_error
print(json.dumps({'replay_match':True,'maximum_absolute_error':max_error,'empirical_validation':False}))
